package com.example.webservices;

import android.content.Context;
import android.os.AsyncTask;
import android.view.View;
import android.webkit.WebChromeClient;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;




